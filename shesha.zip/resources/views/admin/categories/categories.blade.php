@extends("layouts.admin_dash")

@section("content")
    <!-- resources/views/livewire/category-manager.blade.php -->
    {{-- add livewire component --}}
    
    <livewire:admin-category />

@endsection