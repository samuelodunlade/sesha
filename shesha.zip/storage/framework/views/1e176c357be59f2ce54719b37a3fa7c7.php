        <div class="alert alert-success" role="alert">
            <h4 class="alert-heading">Success</h4>
            <p><?php echo e(session("message")); ?></p>
        </div><?php /**PATH C:\xampp\htdocs\shesha\resources\views/components/message.blade.php ENDPATH**/ ?>