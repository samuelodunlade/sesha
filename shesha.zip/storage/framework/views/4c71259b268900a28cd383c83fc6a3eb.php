

<?php $__env->startSection("hero_section"); ?>
    <h1> SHARED SHISHAS  </h1>
    <h3>  <?php echo e($category->title); ?> </h3>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("content"); ?>
<div class="row">
    <!-- main -->
    <div class="col-md-8">
            <!-- all shi -->
        <?php $__currentLoopData = $secrets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secret): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal91ac3d8928a7355bfceab5d42d14dc2e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91ac3d8928a7355bfceab5d42d14dc2e = $attributes; } ?>
<?php $component = App\View\Components\SingleSecret::resolve(['secret' => $secret] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-secret'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSecret::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91ac3d8928a7355bfceab5d42d14dc2e)): ?>
<?php $attributes = $__attributesOriginal91ac3d8928a7355bfceab5d42d14dc2e; ?>
<?php unset($__attributesOriginal91ac3d8928a7355bfceab5d42d14dc2e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91ac3d8928a7355bfceab5d42d14dc2e)): ?>
<?php $component = $__componentOriginal91ac3d8928a7355bfceab5d42d14dc2e; ?>
<?php unset($__componentOriginal91ac3d8928a7355bfceab5d42d14dc2e); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- sidebar -->
        <div class="col-md-4">
            <div class="row">
                <div class="col text-center  mb-4 pt-3">
                    <h4>  Shi Category </h4>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <?php if (isset($component)) { $__componentOriginal8daf9a954c8f412042664b6b343f77c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8daf9a954c8f412042664b6b343f77c0 = $attributes; } ?>
<?php $component = App\View\Components\Category::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('category'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Category::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8daf9a954c8f412042664b6b343f77c0)): ?>
<?php $attributes = $__attributesOriginal8daf9a954c8f412042664b6b343f77c0; ?>
<?php unset($__attributesOriginal8daf9a954c8f412042664b6b343f77c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8daf9a954c8f412042664b6b343f77c0)): ?>
<?php $component = $__componentOriginal8daf9a954c8f412042664b6b343f77c0; ?>
<?php unset($__componentOriginal8daf9a954c8f412042664b6b343f77c0); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col text-center   mb-4 pt-3">
                    <h4> Popular  Secrets </h4>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <div class="shi-cat-box">
                        <?php if (isset($component)) { $__componentOriginalae3a80971b42bd0d6f0ddaff05b2ec61 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae3a80971b42bd0d6f0ddaff05b2ec61 = $attributes; } ?>
<?php $component = App\View\Components\PopularSecrets::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('popular-secrets'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PopularSecrets::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae3a80971b42bd0d6f0ddaff05b2ec61)): ?>
<?php $attributes = $__attributesOriginalae3a80971b42bd0d6f0ddaff05b2ec61; ?>
<?php unset($__attributesOriginalae3a80971b42bd0d6f0ddaff05b2ec61); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae3a80971b42bd0d6f0ddaff05b2ec61)): ?>
<?php $component = $__componentOriginalae3a80971b42bd0d6f0ddaff05b2ec61; ?>
<?php unset($__componentOriginalae3a80971b42bd0d6f0ddaff05b2ec61); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.shisha", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shesha\resources\views/shisha_frontend/bycategory.blade.php ENDPATH**/ ?>