
<div class="row py-5 bg-white">
        <div class="col-md-10 offset-md-1 bg-white">
                <h1 class="mb-4 text-secondary">Category Manager</h1>

                <!--[if BLOCK]><![endif]--><?php if(session('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                        <?php echo e(session('message')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                
                

                <!-- Form -->
            <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h2 class="h5 mb-0"><?php echo e($editMode ? 'Edit Category' : 'Add New Category'); ?></h2>
                    </div>
                    <div class="card-body">
                        <form wire:submit.prevent="<?php echo e($editMode ? 'updateCategory' : 'saveCategory'); ?>">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="title" class="form-label">Title*</label>
                                    <input 
                                        type="text" 
                                        id="title" 
                                        wire:model="title" 
                                        class="form-control"
                                    >
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                
                                <div class="col-md-6">
                                    <label for="cover_image" class="form-label">
                                        <?php echo e($editMode ? 'New Image (leave empty to keep current)' : 'Image*'); ?>

                                    </label>
                                    <input 
                                        type="file" 
                                        id="cover_image" 
                                        wire:model="cover_image" 
                                        class="form-control"
                                    >
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['cover_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                
                                <div class="col-12">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea 
                                        id="description" 
                                        wire:model="description" 
                                        rows="3" 
                                        class="form-control"
                                    ></textarea>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-check form-switch">
                                        <input 
                                            type="checkbox" 
                                            wire:model="status" 
                                            id="status" 
                                            class="form-check-input"
                                            role="switch"
                                        >
                                        <label for="status" class="form-check-label">Active</label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4 d-flex justify-content-end gap-2">
                                <!--[if BLOCK]><![endif]--><?php if($editMode): ?>
                                    <button 
                                        type="button" 
                                        wire:click="resetForm" 
                                        class="btn btn-outline-secondary"
                                    >
                                        Cancel
                                    </button>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                
                                <button 
                                    type="submit" 
                                    class="btn btn-primary bg-primary"
                                >
                                    <i class="bi bi-save me-1"></i>
                                    <?php echo e($editMode ? 'Update' : 'Save'); ?> Category
                                </button>
                            </div>
                        </form>
                    </div>
            </div>
            <hr class="my-5">
            <!-- Search -->
            <div class="mb-4">
                <div class="input-group">
                    <input 
                        type="text" 
                        wire:model.debounce.500ms="search" 
                        placeholder="Search categories..."
                        wire:keyup.debounce.500ms="loadCategories"
                        class="form-control"
                    >
                    <span class="input-group-text" wire:click='loadCategories' style="cursor: pointer">
                        <i class="bi bi-search"></i>
                    </span>
                </div>
            </div>

             <!-- Categories Table -->
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h2 class="h5 mb-0">Categories List</h2>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Cover Image</th>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <!--[if BLOCK]><![endif]--><?php if($category->cover_image): ?>
                                                <img src="<?php echo e(asset('storage/'.$category->cover_image)); ?>" 
                                                    alt="<?php echo e($category->title); ?>" 
                                                    class="img-thumbnail" 
                                                    style="width: 60px; height: 60px; object-fit: cover">
                                            <?php else: ?>
                                                <div class="bg-light d-flex align-items-center justify-content-center" 
                                                    style="width: 60px; height: 60px;">
                                                    <i class="bi bi-image text-muted" style="font-size: 1.5rem;"></i>
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </td>
                                        <td><?php echo e($category->title); ?></td>
                                        <td>
                                            <div class="text-truncate" style="max-width: 200px;">
                                                <?php echo e($category->description); ?>

                                            </div>
                                        </td>
                                        <td>
                                            <button 
                                                wire:click="toggleStatus(<?php echo e($category->id); ?>)" 
                                                class="btn btn-sm <?php echo e($category->status=="active" ? 'btn-success' : 'btn-danger'); ?>"
                                            >
                                                <?php echo e($category->status=="active" ? 'Active' : 'Inactive'); ?>

                                            </button>
                                        </td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <button 
                                                    wire:click="edit(<?php echo e($category->id); ?>)" 
                                                    class="btn btn-sm btn-outline-primary"
                                                    title="Edit"
                                                >
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                                <button 
                                                    wire:click="deleteCategory(<?php echo e($category->id); ?>)" 
                                                    class="btn btn-sm btn-outline-danger"
                                                    title="Delete"
                                                    onclick="return confirm('Are you sure you want to delete this category?')"
                                                >
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-4 text-muted">
                                            No categories found.
                                        </td>
                                    </tr>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-4">
                        <?php echo e($categories->links()); ?>

                    </div>
                </div>
            </div>
            
        </div>
</div> 


<?php /**PATH C:\xampp\htdocs\shesha\resources\views/livewire/admin-category.blade.php ENDPATH**/ ?>