

<?php $__env->startSection("page_name", "Forget Password"); ?>


<?php $__env->startSection("content"); ?>
    <p class="text-center">Enter Your email to recover your password.</p>
    <?php if(session("status")): ?>
        <p class="alert alert-success">
            <?php echo e(session("status")); ?>

        </p>
    <?php endif; ?>
    <form action="<?php echo e(route('password.email')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-floating mb-3">
            <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com" name="email">
            <label for="floatingInput">Email address</label>
            <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="alert alert-danger">
                    <?php echo e($message); ?>

                </p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn btn-primary py-3 w-100 mb-4">Email Password Reset Link</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shesha\resources\views/shi_auth/forgot-password.blade.php ENDPATH**/ ?>