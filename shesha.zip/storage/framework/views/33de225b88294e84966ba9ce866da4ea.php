<ul class="list-group">
    <?php $__currentLoopData = $popularSecrets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secret): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item"> <a href="/secrets/<?php echo e($secret->slug); ?>"><?php echo e($secret->title); ?></a> </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\xampp\htdocs\shesha\resources\views/components/popular-secrets.blade.php ENDPATH**/ ?>