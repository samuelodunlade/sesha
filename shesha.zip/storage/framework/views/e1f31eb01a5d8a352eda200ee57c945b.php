<!--[if BLOCK]><![endif]--><?php if($sortDirection === 'asc'): ?>
    <i class="bi bi-arrow-up"></i>
<?php else: ?>
    <i class="bi bi-arrow-down"></i>
<?php endif; ?><!--[if ENDBLOCK]><![endif]--><?php /**PATH C:\xampp\htdocs\shesha\resources\views/partials/sort-icon.blade.php ENDPATH**/ ?>