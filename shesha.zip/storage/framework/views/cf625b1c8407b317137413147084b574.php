

<?php $__env->startSection("content"); ?>

<div class="row py-5 bg-white">
    <div class="col-md-10 offset-md-1 bg-white">
            <h1 class="mb-4 text-secondary">Secret Records</h1>
    </div>
    
    <div class="col-md-10 offset-md-1 bg-white">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0 text-primary">Top Five Most Viewed Secrets</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th> Title </th>
                                <th> Category </th>
                                <th> Upvote </th>
                                <th> Downvote </th>
                                <th> Views </th>
                                <th> Date </th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $most_viewed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secret): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($secret->title); ?></td>
                                    <td><?php echo e($secret->category->title); ?></td>
                                    <td><?php echo e($secret->upvotes); ?></td>
                                    <td><?php echo e($secret->downvotes); ?></td>
                                    <td><?php echo e($secret->views); ?></td>
                                    <td><?php echo e($secret->created_at); ?></td>
                                    <td>
                                        <?php if($secret->expires_at && $secret->expires_at->isPast()): ?>
                                            <span class="badge bg-danger">Expired</span>
                                        <?php elseif($secret->expires_at): ?>
                                            <span class="badge bg-warning text-dark">
                                                Expires: <?php echo e($secret->expires_at->diffForHumans()); ?>

                                            </span>
                                        <?php endif; ?>
                                        <?php if($secret->is_blocked): ?>
                                        <span class="badge bg-danger">Blocked</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">Active</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><a href="<?php echo e(route('admin.secrets.show', $secret->id)); ?>" class="btn btn-primary">View</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div> 
    </div>  

    
    <div class="col-md-10 offset-md-1 bg-white">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0 text-primary">Top Five Most Liked Secrets</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th> Title </th>
                                <th> Category </th>
                                <th> Upvote </th>
                                <th> Downvote </th>
                                <th> Views </th>
                                <th> Date </th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $most_liked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secret): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($secret->title); ?></td>
                                    <td><?php echo e($secret->category->title); ?></td>
                                    <td><?php echo e($secret->upvotes); ?></td>
                                    <td><?php echo e($secret->downvotes); ?></td>
                                    <td><?php echo e($secret->views); ?></td>
                                    <td><?php echo e($secret->created_at); ?></td>
                                    <td>
                                        <?php if($secret->expires_at && $secret->expires_at->isPast()): ?>
                                            <span class="badge bg-danger">Expired</span>
                                        <?php elseif($secret->expires_at): ?>
                                            <span class="badge bg-warning text-dark">
                                                Expires: <?php echo e($secret->expires_at->diffForHumans()); ?>

                                            </span>
                                        <?php endif; ?>
                                        <?php if($secret->is_blocked): ?>
                                        <span class="badge bg-danger">Blocked</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">Active</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><a href="<?php echo e(route('admin.secrets.show', $secret->id)); ?>" class="btn btn-primary">View</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div> 
    </div> 

    
    
    <div class="col-md-10 offset-md-1 bg-white">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0 text-primary">Top Five Most DisLiked Secrets</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th> Title </th>
                                <th> Category </th>
                                <th> Upvote </th>
                                <th> Downvote </th>
                                <th> Views </th>
                                <th> Date </th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $most_disliked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secret): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($secret->title); ?></td>
                                    <td><?php echo e($secret->category->title); ?></td>
                                    <td><?php echo e($secret->upvotes); ?></td>
                                    <td><?php echo e($secret->downvotes); ?></td>
                                    <td><?php echo e($secret->views); ?></td>
                                    <td><?php echo e($secret->created_at); ?></td>
                                    <td>
                                        <?php if($secret->expires_at && $secret->expires_at->isPast()): ?>
                                            <span class="badge bg-danger">Expired</span>
                                        <?php elseif($secret->expires_at): ?>
                                            <span class="badge bg-warning text-dark">
                                                Expires: <?php echo e($secret->expires_at->diffForHumans()); ?>

                                            </span>
                                        <?php endif; ?>
                                        <?php if($secret->is_blocked): ?>
                                        <span class="badge bg-danger">Blocked</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">Active</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><a href="<?php echo e(route('admin.secrets.show', $secret->id)); ?>" class="btn btn-primary">View</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div> 
    </div> 
   

    



</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shesha\resources\views/admin/records.blade.php ENDPATH**/ ?>