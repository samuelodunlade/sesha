<div class="row">
    <div class="col">
        <div class="shi-box">
            <div class="shi-main">
                <h3><?php echo e($secret->title); ?></h3>
                
                <div class="tag-container">
                    <span> <strong>      Admin Tag:</strong> </span>
                    <?php $__empty_1 = true; $__currentLoopData = $secret->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        
                            <span class="badge bg-primary py-2 mytag">
                                <a href="/secrets/tag/<?php echo e($tag->slug); ?>" class="text-decoration-none">
                                <?php echo e($tag->name); ?>

                                </a>
                            </span>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span class="badge bg-primary py-2">
                            Untagged
                        </span>
                    <?php endif; ?>
                </div>
               

                <p> <?php echo e($secret->summary); ?> </p>
                
                <hr>
                <a href="/secrets/<?php echo e($secret->slug); ?>" class="btn btn-primary"> <i class="fa-solid fa-eye"></i> Detail Shi</a>


            </div>
            <div class="shi-stat">
                <p class="text-muted">
                    <i class="fa-solid fa-eye"></i>
                    <span><?php echo e($secret->views); ?></span>
                </p>
                <p class="text-muted">
                    <i class="fa-solid fa-thumbs-up"></i>
                    <span> <?php echo e($secret->upvotes); ?> </span>
                </p>

                <p class="text-muted">
                    <i class="fa-solid fa-thumbs-down"></i>
                    <span><?php echo e($secret->downvotes); ?></span>
                </p>
                <p class="text-muted">
                    <i class="fa-solid fa-clock"></i>
                   <span class="small"> <?php echo e($secret->created_at->diffForHumans()); ?> </span>
                </p>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\shesha\resources\views/components/single-secret.blade.php ENDPATH**/ ?>