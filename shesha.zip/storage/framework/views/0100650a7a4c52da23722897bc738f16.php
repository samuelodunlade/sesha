

<?php $__env->startSection("content"); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>    
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center pb-5 pt-3">
        <h1 class="card-title text-secondary">Tags</h1>
        <div class="card-tools">
            <a href="<?php echo e(route('admin.tags.create')); ?>" class="btn btn-primary">Add Tag</a>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Slug</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($tag->name); ?></td>
                    <td><?php echo e($tag->slug); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.tags.edit', $tag->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('admin.tags.destroy', $tag->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer clearfix">
        
    </div>
</div>


    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_dash", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shesha\resources\views/admin/tags/index.blade.php ENDPATH**/ ?>