

<?php $__env->startSection("content"); ?>

<div class="card">
    <div class="card-header pt-3 pb-5 d-flex justify-content-between align-items-center">
        <h1 class="card-title text-secondary">Create Tag</h1>
        <a href="<?php echo e(route('admin.tags.index')); ?>" class="btn btn-secondary">Back to Tags</a>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('admin.tags.store')); ?>" method="post" class="p-5">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name" class="mb-2">Tag Name</label>
                <input type="text" class="form-control my-3" id="name" name="name" placeholder="Enter tag name">
                <?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger my-2">
                        <?php echo e($message); ?>


                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-primary">Create Tag</button>
        </form>
    </div>
    <div class="card-footer">
        
    </div>
</div>

    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_dash", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shesha\resources\views/admin/tags/create.blade.php ENDPATH**/ ?>